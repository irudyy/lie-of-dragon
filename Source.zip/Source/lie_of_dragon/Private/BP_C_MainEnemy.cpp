// Fill out your copyright notice in the Description page of Project Settings.


#include "BP_C_MainEnemy.h"

#include "C_BP_EnemyWidget.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "InputCoreTypes.h"
#include "GameFramework/GameSession.h"
#include "GeometryCollection/GeometryCollectionDebugDrawActor.h"
#include "StateTree.h"


#include "Blueprint/UserWidget.h"
#include "Components/ProgressBar.h"
#include "Kismet/GameplayStatics.h"
#include "Camera/PlayerCameraManager.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/KismetMathLibrary.h"
#include "Components/SceneComponent.h"


// Sets default values
ABP_C_MainEnemy::ABP_C_MainEnemy()
{
 	
	PrimaryActorTick.bCanEverTick = true;
	GetMesh()->SetRelativeRotation(FRotator {0.f, 0.f, 0.f});
	StateTree = CreateDefaultSubobject<UStateTreeComponent>(TEXT("StateTree"));
	
	WidgetHealthBar = CreateDefaultSubobject<UWidgetComponent>(TEXT("HealthBarComponent"));
	WidgetHealthBar->SetupAttachment(RootComponent);
	WidgetHealthBar->SetWidgetSpace(EWidgetSpace::World); // виджет в мировом пространстве
	
	
}



// Called when the game starts or when spawned
void ABP_C_MainEnemy::BeginPlay()
{
	Super::BeginPlay();
	
	/*if (WidgetHealthBar)
	{
		WidgetHealthBar = Cast<UC_BP_EnemyWidget>(WidgetHealthBar->GetUserWidgetObject());
	}*/
}

	


// Called every frame
void ABP_C_MainEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!WidgetHealthBar)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 0.0f, FColor::Red, TEXT("WidgetHealthBar is NULL"));
		}
		return;
	}

	UUserWidget* UserWidget = WidgetHealthBar->GetUserWidgetObject();

	if (!UserWidget)
	{
		WidgetHealthBar->InitWidget();
		UserWidget = WidgetHealthBar->GetUserWidgetObject();

		if (!UserWidget)
		{
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 0.0f, FColor::Red, TEXT("Enemy UserWidget is NULL"));
			}
			return;
		}
	}

	UC_BP_EnemyWidget* EnemyWidget = Cast<UC_BP_EnemyWidget>(UserWidget);

	if (!EnemyWidget)
	{
		if (GEngine)
		{
			const FString Msg = FString::Printf(
				TEXT("Enemy widget cast FAILED: %s"),
				*UserWidget->GetClass()->GetName()
			);

			GEngine->AddOnScreenDebugMessage(-1, 0.0f, FColor::Red, Msg);
		}
		return;
	}

	if (!EnemyWidget->HPBar)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 0.0f, FColor::Red, TEXT("EnemyWidget HPBar is NULL"));
		}
		return;
	}

	const float HealthPercent = C_MaxHealth > 0.0
		? FMath::Clamp(static_cast<float>(C_CurrentHealth / C_MaxHealth), 0.0f, 1.0f)
		: 0.0f;

	EnemyWidget->HPBar->SetPercent(HealthPercent);

	if (GEngine)
	{
		const FString Msg = FString::Printf(
			TEXT("ENEMY WIDGET UPDATE | HP %.0f / %.0f | Percent %.2f"),
			C_CurrentHealth,
			C_MaxHealth,
			HealthPercent
		);

		GEngine->AddOnScreenDebugMessage(-1, 0.0f, FColor::Cyan, Msg);
	}

	APlayerController* PC = GetWorld()->GetFirstPlayerController();

	if (PC && PC->PlayerCameraManager)
	{
		FVector CameraLocation = PC->PlayerCameraManager->GetCameraLocation();

		FRotator LookAtRotation = UKismetMathLibrary::FindLookAtRotation(
			WidgetHealthBar->GetComponentLocation(),
			CameraLocation
		);

		WidgetHealthBar->SetWorldRotation(LookAtRotation);
	}
}

// Called to bind functionality to input
void ABP_C_MainEnemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void ABP_C_MainEnemy::EnemyMove(const FInputActionValue& ActionValue)
{
	FVector2D ActionVector = ActionValue.Get<FVector2D>();

	
	AddMovementInput(GetActorForwardVector(), ActionVector.Y);
	AddMovementInput(GetActorRightVector(), ActionVector.X);
}

